<form class="search searchform" action="<?php echo home_url(); ?>/" method="get">
	<fieldset>
		<span class="text"><input name="s" class="s" type="text" value="" placeholder="<?php echo __('Search ...', 'Avada'); ?>" /></span>
	</fieldset>
</form>